<?php
namespace App\Http\Controllers\autoWeb;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;
use App\theloai;
use App\sanpham;
class SearchController extends Controller
{
    protected function getdatasearch(Request $req){
    	$search = $req->query('search');
    	$theloai = theloai::where('name', 'like',"%".$search."%")->get();
    	$sanpham = sanpham::where('name', 'like',"%".$search."%")->get();
    	return [
    		'theloai' => $theloai,
    		'sanpham' => $sanpham
    	];    }
    protected function view(){
    	return view('autoWeb.search');
    }
}